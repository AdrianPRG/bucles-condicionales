<nav
    class="navbar navbar-expand-sm navbar-dark colorheader">
        <div class="container">

                <img src="../imagenes/db.png" width="60px">
                <div style="text-align: center;">
                    <h2 style="font-size:40px;" class="navbar-brand mx-auto textoweb">Dragon ball Z</h2>
                    <h4 class="textoweb">"Break your limits!"</h4>
                </div>
                <img src="../imagenes/db.png" width="60px">
        </div>
</nav>
