<nav class="navbar colorfooter navbar-expand-sm border-bottom border-body" style="text-align: center;justify-content:center">
  <div class="contanier">
    <a href="https://www3.animeflv.net/">Ir a pagina de Animeflv</a>
    <img class="ms-4 mt-2 mb-2" src="../imagenes/flv.png" width="50px">
  </div>
</nav>