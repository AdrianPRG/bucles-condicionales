<nav
    class="navbar navbar-expand-sm navbar-dark colorheader" style="width: 100%;">
        <div class="container">
                <img src="../imagenes/snk.png" width="60px">
                <div style="text-align: center;">
                    <h2 style="font-size:40px;" class="navbar-brand mx-auto textoweb">Attack on Titan</h2>
                    <h4 class="textoweb">"I will keep moving forward..."</h4>
                </div>
                <img src="../imagenes/snk.png" width="60px">
        </div>
</nav>
