<nav
    class="navbar navbar-expand-sm navbar-dark colorheader">
        <div class="container">
           
                <img src="../imagenes/op.png" width="120px">
                <div style="text-align: center;">
                    <h2 style="font-size:40px;" class="navbar-brand mx-auto textoweb">One Piece</h2>
                    <h4 class="textoweb">"I'm gonna be the king of pirates!</h4>
                </div>
                <img src="../imagenes/op.png" width="120px">
        </div>
</nav>
