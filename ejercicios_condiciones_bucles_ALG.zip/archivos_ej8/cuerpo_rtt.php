
<div style="width:100%;height:80%;display:flex" class="colorCuerpo">
    <div style="position:relative;width:40%;height:100%">
        <div style="position:absolute;top:50%;left:50%;transform: translate(-50%, -50%)">
            <img  src="../imagenes/rotten.png" style="margin:20;" width="100%">
        </div>
    </div>
    <div style="position:relative; width:60%; height:100%;border:0.1em solid;overflow: hidden;" class="colorCuerpo"> <!-- Cambiado a 60% -->
        <div style="position:absolute; top:50%; left:50%; transform: translate(-50%, -50%); text-align: center; width: 100%;">
            <h1 style="font-size: 3vw;text-align:justify; margin-left: 40px; margin-right:40px" class="textoweb">Rotten tomatoes es una web que recopila críticas de películas realizadas por otros medios,recoge y sintetiza reseñas de críticos y audiencia, para ofrecer una puntuación aproximada.</h1>
        </div>
    </div>
</div>