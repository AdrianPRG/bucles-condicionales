<nav class="navbar colorfooter navbar-expand-sm border-bottom border-body" style="text-align: center;justify-content:center;height:9%">
  <div class="contanier">
    <a href="https://www.primevideo.com/">Ir a pagina de Prime Video</a>
    <img class="ms-4 mt-2 mb-2" src="../imagenes/prime.png" width="50px">
    </div>
</nav>
