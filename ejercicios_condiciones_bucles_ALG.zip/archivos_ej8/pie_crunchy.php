<nav class="navbar colorfooter navbar-expand-sm border-bottom border-body" style="text-align: center;justify-content:center">
  <div class="contanier">
    <a href="https://www.crunchyroll.com/">Ir a pagina de crunchyroll</a>
      <img class="ms-4 mt-2 mb-2" src="../imagenes/crunchy.png" width="50px">
  </div>
</nav>